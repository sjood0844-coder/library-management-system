# Library Management System Database

A university database project for a public library. The database is designed to organize books, categories, members, borrowing transactions, study halls, and room reservations.

## Project overview

The project covers relational database design and implementation using MySQL. It includes an Entity Relationship Diagram (ERD), relational schema, table creation, integrity constraints, sample query tasks, and a reporting view.

## Database entities

- `Category`: book categories.
- `Books`: book details and category references.
- `Members`: library member details.
- `Member_Phones`: phone numbers associated with members.
- `Borrowings`: book borrowing and return records.
- `Halls`: library rooms and their usage schedules.
- `Reservations`: member reservations for library halls.

## Tools and concepts

- MySQL
- SQL
- Entity Relationship Diagram (ERD)
- Relational schema design
- Primary keys and foreign keys
- UNIQUE, NOT NULL, CHECK, and ENUM constraints
- JOINs, aggregate functions, subqueries, and SQL views

## Files

- `sql/library_schema.sql` — table definitions and the reservation reporting view.

## How to use

1. Open MySQL Workbench or another MySQL client.
2. Run the statements in `sql/library_schema.sql`.
3. Add your own test records if you want to practice the queries.

> Note: This repository contains the database structure and reporting view. Personal identifiers and example contact details from the original class report are intentionally not included.

## Academic contribution

My assigned contributions included preparing the ER diagram, writing a JOIN query, preparing the report, and creating a database view for a simple report.
